﻿namespace Хороскоп
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Vaga = new System.Windows.Forms.Button();
            this.Ribi = new System.Windows.Forms.Button();
            this.Strelec = new System.Windows.Forms.Button();
            this.Jarec = new System.Windows.Forms.Button();
            this.Skorpija = new System.Windows.Forms.Button();
            this.Devica = new System.Windows.Forms.Button();
            this.Rak = new System.Windows.Forms.Button();
            this.Vodolija = new System.Windows.Forms.Button();
            this.Bliznaci = new System.Windows.Forms.Button();
            this.Bik = new System.Windows.Forms.Button();
            this.Oven = new System.Windows.Forms.Button();
            this.Lav = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Vaga
            // 
            this.Vaga.Image = global::Хороскоп.Properties.Resources._935c2aceaf38a82b893b60463ac757d0;
            this.Vaga.Location = new System.Drawing.Point(1561, 506);
            this.Vaga.Name = "Vaga";
            this.Vaga.Size = new System.Drawing.Size(302, 424);
            this.Vaga.TabIndex = 11;
            this.Vaga.UseVisualStyleBackColor = true;
            this.Vaga.Click += new System.EventHandler(this.Vaga_Click);
            // 
            // Ribi
            // 
            this.Ribi.Image = global::Хороскоп.Properties.Resources._0af68ea5160aed2afbf7e4aa78b773e4;
            this.Ribi.Location = new System.Drawing.Point(1204, 506);
            this.Ribi.Name = "Ribi";
            this.Ribi.Size = new System.Drawing.Size(302, 424);
            this.Ribi.TabIndex = 10;
            this.Ribi.UseVisualStyleBackColor = true;
            this.Ribi.Click += new System.EventHandler(this.Ribi_Click);
            // 
            // Strelec
            // 
            this.Strelec.Image = global::Хороскоп.Properties.Resources._4a57e7c760d15c08542ed3364db386fd;
            this.Strelec.Location = new System.Drawing.Point(891, 506);
            this.Strelec.Name = "Strelec";
            this.Strelec.Size = new System.Drawing.Size(270, 424);
            this.Strelec.TabIndex = 9;
            this.Strelec.UseVisualStyleBackColor = true;
            this.Strelec.Click += new System.EventHandler(this.Strelec_Click);
            // 
            // Jarec
            // 
            this.Jarec.Image = global::Хороскоп.Properties.Resources.artistic_zodiac_capricorn_astrology_horoscope_zodiac_sign_hd_wallpaper_preview;
            this.Jarec.Location = new System.Drawing.Point(588, 506);
            this.Jarec.Name = "Jarec";
            this.Jarec.Size = new System.Drawing.Size(266, 424);
            this.Jarec.TabIndex = 8;
            this.Jarec.UseVisualStyleBackColor = true;
            this.Jarec.Click += new System.EventHandler(this.Jarec_Click);
            // 
            // Skorpija
            // 
            this.Skorpija.Image = global::Хороскоп.Properties.Resources.a77d49d961c7f6393c8ea1caa02d2edf;
            this.Skorpija.Location = new System.Drawing.Point(289, 506);
            this.Skorpija.Name = "Skorpija";
            this.Skorpija.Size = new System.Drawing.Size(253, 424);
            this.Skorpija.TabIndex = 7;
            this.Skorpija.UseVisualStyleBackColor = true;
            this.Skorpija.Click += new System.EventHandler(this.Skorpija_Click);
            // 
            // Devica
            // 
            this.Devica.Image = global::Хороскоп.Properties.Resources.headers_zodiac_sign_astrology_personality_positives_negatives_cheat_sheet_virgo_1500x;
            this.Devica.Location = new System.Drawing.Point(21, 506);
            this.Devica.Name = "Devica";
            this.Devica.Size = new System.Drawing.Size(246, 424);
            this.Devica.TabIndex = 6;
            this.Devica.UseVisualStyleBackColor = true;
            this.Devica.Click += new System.EventHandler(this.Devica_Click);
            // 
            // Rak
            // 
            this.Rak.Image = global::Хороскоп.Properties.Resources.istockphoto_538871860_612x612;
            this.Rak.Location = new System.Drawing.Point(1561, 50);
            this.Rak.Name = "Rak";
            this.Rak.Size = new System.Drawing.Size(302, 424);
            this.Rak.TabIndex = 5;
            this.Rak.UseVisualStyleBackColor = true;
            this.Rak.Click += new System.EventHandler(this.Rak_Click);
            // 
            // Vodolija
            // 
            this.Vodolija.Image = global::Хороскоп.Properties.Resources.bf8c0f86b49642ac9130e89043ed9e7f;
            this.Vodolija.Location = new System.Drawing.Point(1204, 50);
            this.Vodolija.Name = "Vodolija";
            this.Vodolija.Size = new System.Drawing.Size(302, 424);
            this.Vodolija.TabIndex = 4;
            this.Vodolija.UseVisualStyleBackColor = true;
            this.Vodolija.Click += new System.EventHandler(this.Vodolija_Click);
            // 
            // Bliznaci
            // 
            this.Bliznaci.Image = global::Хороскоп.Properties.Resources.godisen_horoskop_za_2014_godina_bliznaci_02;
            this.Bliznaci.Location = new System.Drawing.Point(891, 50);
            this.Bliznaci.Name = "Bliznaci";
            this.Bliznaci.Size = new System.Drawing.Size(270, 424);
            this.Bliznaci.TabIndex = 3;
            this.Bliznaci.UseVisualStyleBackColor = true;
            this.Bliznaci.Click += new System.EventHandler(this.Bliznaci_Click);
            // 
            // Bik
            // 
            this.Bik.BackgroundImage = global::Хороскоп.Properties.Resources.taurus_7777654_960_720;
            this.Bik.Image = global::Хороскоп.Properties.Resources.taurus_7777654_960_720;
            this.Bik.Location = new System.Drawing.Point(588, 50);
            this.Bik.Name = "Bik";
            this.Bik.Size = new System.Drawing.Size(266, 424);
            this.Bik.TabIndex = 2;
            this.Bik.UseVisualStyleBackColor = true;
            this.Bik.Click += new System.EventHandler(this.Bik_Click);
            // 
            // Oven
            // 
            this.Oven.Image = global::Хороскоп.Properties.Resources.ovan_horoskop_horoskopski_znak_830x0_1_e1592785560735;
            this.Oven.Location = new System.Drawing.Point(289, 50);
            this.Oven.Name = "Oven";
            this.Oven.Size = new System.Drawing.Size(253, 424);
            this.Oven.TabIndex = 1;
            this.Oven.UseVisualStyleBackColor = true;
            this.Oven.Click += new System.EventHandler(this.Oven_Click);
            // 
            // Lav
            // 
            this.Lav.Image = global::Хороскоп.Properties.Resources.desktop_wallpaper_leo_zodiac_sign_leo_aesthetic_thumbnail;
            this.Lav.Location = new System.Drawing.Point(21, 50);
            this.Lav.Name = "Lav";
            this.Lav.Size = new System.Drawing.Size(246, 424);
            this.Lav.TabIndex = 0;
            this.Lav.UseVisualStyleBackColor = true;
            this.Lav.Click += new System.EventHandler(this.Lav_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1904, 1041);
            this.Controls.Add(this.Vaga);
            this.Controls.Add(this.Ribi);
            this.Controls.Add(this.Strelec);
            this.Controls.Add(this.Jarec);
            this.Controls.Add(this.Skorpija);
            this.Controls.Add(this.Devica);
            this.Controls.Add(this.Rak);
            this.Controls.Add(this.Vodolija);
            this.Controls.Add(this.Bliznaci);
            this.Controls.Add(this.Bik);
            this.Controls.Add(this.Oven);
            this.Controls.Add(this.Lav);
            this.Name = "Form1";
            this.Text = "Хороскоп";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Lav;
        private System.Windows.Forms.Button Oven;
        private System.Windows.Forms.Button Bik;
        private System.Windows.Forms.Button Bliznaci;
        private System.Windows.Forms.Button Vodolija;
        private System.Windows.Forms.Button Rak;
        private System.Windows.Forms.Button Vaga;
        private System.Windows.Forms.Button Ribi;
        private System.Windows.Forms.Button Strelec;
        private System.Windows.Forms.Button Jarec;
        private System.Windows.Forms.Button Skorpija;
        private System.Windows.Forms.Button Devica;
    }
}

